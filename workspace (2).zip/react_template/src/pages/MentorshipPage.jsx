import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { teamsData } from '../data/teamsData';
import NavBar from '../components/NavBar';
import BottomNav from '../components/BottomNav';
import MentorshipFilters from '../components/mentorship/MentorshipFilters';
import MentorshipResults from '../components/mentorship/MentorshipResults';
import { findMatchingTeams } from '../utils/mentorshipUtils';

const MentorshipPage = () => {
  const [searchParams] = useSearchParams();
  const [currentTeam, setCurrentTeam] = useState(null);
  const [inputTeamInfo, setInputTeamInfo] = useState({
    name: searchParams.get('name') || '',
    number: searchParams.get('number') || ''
  });
  const [filters, setFilters] = useState({
    category: [],
    expertiseAreas: [],
    mentorshipType: '',
    distance: 100, // in miles
    experience: 0
  });
  const [matches, setMatches] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searchAttempted, setSearchAttempted] = useState(false);

  // Effect to process URL parameters when component mounts
  useEffect(() => {
    const name = searchParams.get('name');
    const number = searchParams.get('number');
    
    if (name && number) {
      // Try to find a team with matching name and number
      const matchedTeam = teamsData.find(team => 
        team.name.toLowerCase().includes(name.toLowerCase()) && 
        team.number.toString() === number
      );
      
      if (matchedTeam) {
        setCurrentTeam(matchedTeam);
      } else {
        setSearchAttempted(true);
      }
    }
  }, [searchParams]);

  // Effect to load matches when filters or current team changes
  useEffect(() => {
    if (currentTeam) {
      setLoading(true);
      // Simulate API call with a small delay
      setTimeout(() => {
        const matchedTeams = findMatchingTeams(currentTeam, filters, teamsData);
        setMatches(matchedTeams);
        setLoading(false);
      }, 500);
    }
  }, [currentTeam, filters]);

  // Function to handle filter changes
  const handleFilterChange = (newFilters) => {
    setFilters({ ...filters, ...newFilters });
  };

  // Function to handle team selection
  const handleTeamSelect = (teamId) => {
    const team = teamsData.find(team => team.id === parseInt(teamId));
    setCurrentTeam(team);
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <NavBar />
      <div className="container mx-auto px-4 py-8 flex-grow mt-14">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-blue-800 mb-2">RoboHive Mentorship Matchmaking</h1>
          <p className="text-xl text-gray-600">Find the perfect mentoring partnership for your robotics team</p>
        </div>

        <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
          <h2 className="text-2xl font-semibold text-gray-800 mb-4">Your Team Information</h2>
          
          {/* Show selected team info if a team is selected */}
          {currentTeam && (
            <div>
              <div className="bg-blue-50 border border-blue-200 rounded-md p-4 mb-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-lg font-semibold">{currentTeam.name}</h3>
                    <p className="text-gray-600">Team #{currentTeam.number} • {currentTeam.location}</p>
                    <p className="mt-2">Looking to {currentTeam.mentorshipStatus === "offering" ? "provide mentorship" : "receive mentorship"}</p>
                  </div>
                  <button 
                    onClick={() => {
                      setCurrentTeam(null);
                      setMatches([]);
                    }}
                    className="text-blue-600 hover:text-blue-800"
                  >
                    Change Team
                  </button>
                </div>
              </div>
            </div>
          )}
          
          {/* Show manual input form if no team is selected yet */}
          {!currentTeam && (
            <div>
              <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 mb-6">
                <div>
                  <label htmlFor="teamName" className="block text-sm font-medium text-gray-700 mb-1">
                    Team Name
                  </label>
                  <input
                    id="teamName"
                    type="text"
                    value={inputTeamInfo.name}
                    onChange={(e) => setInputTeamInfo({...inputTeamInfo, name: e.target.value})}
                    className="mt-1 block w-full p-2.5 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                    placeholder="Enter your team name"
                  />
                </div>
                <div>
                  <label htmlFor="teamNumber" className="block text-sm font-medium text-gray-700 mb-1">
                    Team Number
                  </label>
                  <input
                    id="teamNumber"
                    type="text"
                    value={inputTeamInfo.number}
                    onChange={(e) => setInputTeamInfo({...inputTeamInfo, number: e.target.value})}
                    className="mt-1 block w-full p-2.5 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                    placeholder="Enter your team number"
                  />
                </div>
              </div>
              
              <div className="flex justify-between">
                <button
                  onClick={() => {
                    const matchedTeam = teamsData.find(team => 
                      team.name.toLowerCase().includes(inputTeamInfo.name.toLowerCase()) && 
                      team.number.toString() === inputTeamInfo.number
                    );
                    
                    if (matchedTeam) {
                      setCurrentTeam(matchedTeam);
                      setSearchAttempted(false);
                    } else {
                      setSearchAttempted(true);
                    }
                  }}
                  className="py-2 px-4 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none"
                >
                  Find My Team
                </button>
                
                <div className="flex items-center">
                  <span className="mr-2 text-sm text-gray-600">or</span>
                  <select
                    id="teamSelect"
                    className="block p-2.5 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                    onChange={(e) => handleTeamSelect(e.target.value)}
                    defaultValue=""
                  >
                    <option value="" disabled>Select from list</option>
                    {teamsData.map((team) => (
                      <option key={team.id} value={team.id}>
                        {team.number} - {team.name} ({team.mentorshipStatus === "offering" ? "Mentor" : "Mentee"})
                      </option>
                    ))}
                  </select>
                </div>
              </div>
              
              {/* Show message if search was attempted but no team was found */}
              {searchAttempted && (
                <div className="mt-4 p-3 bg-red-100 text-red-700 rounded-md">
                  No team found with the provided name and number. Please check your information or select from the list.
                </div>
              )}
            </div>
          )}
          
          {currentTeam && (
            <div className="p-4 bg-blue-50 rounded-lg mb-6">
              <div className="flex items-center">
                <div className="w-16 h-16 bg-gray-300 rounded-full overflow-hidden mr-4">
                  <img 
                    src={currentTeam.profileImage} 
                    alt={`${currentTeam.name} profile`} 
                    className="w-full h-full object-cover"
                  />
                </div>
                <div>
                  <h3 className="text-xl font-semibold">{currentTeam.name} (#{currentTeam.number})</h3>
                  <p className="text-gray-600">{currentTeam.location} | {currentTeam.category}</p>
                  <p className="text-blue-700 font-medium mt-1">
                    {currentTeam.mentorshipStatus === "offering" ? "Offering Mentorship" : "Seeking Mentorship"}
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>

        {currentTeam && (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="md:col-span-1">
              <MentorshipFilters 
                currentTeam={currentTeam}
                filters={filters} 
                onFilterChange={handleFilterChange} 
              />
            </div>
            <div className="md:col-span-3">
              <MentorshipResults 
                matches={matches} 
                currentTeam={currentTeam}
                loading={loading} 
              />
            </div>
          </div>
        )}
      </div>

      <BottomNav />
    </div>
  );
};

export default MentorshipPage;