import React from 'react';
import { getUniqueCategories, getUniqueExpertiseAreas } from '../../utils/mentorshipUtils';
import { teamsData } from '../../data/teamsData';

const MentorshipFilters = ({ currentTeam, filters, onFilterChange }) => {
  // Get unique categories and expertise areas from teams data
  const categories = getUniqueCategories(teamsData);
  const expertiseAreas = getUniqueExpertiseAreas(teamsData);

  // Handle checkbox change for multiple selection filters
  const handleMultipleSelect = (e, filterName) => {
    const value = e.target.value;
    const isChecked = e.target.checked;
    
    let updatedValues = [...filters[filterName]];
    
    if (isChecked) {
      updatedValues.push(value);
    } else {
      updatedValues = updatedValues.filter(item => item !== value);
    }
    
    onFilterChange({ [filterName]: updatedValues });
  };

  // Handle single value inputs
  const handleInputChange = (e, filterName) => {
    onFilterChange({ [filterName]: e.target.value });
  };

  // Handle numeric inputs
  const handleNumericChange = (e, filterName) => {
    onFilterChange({ [filterName]: parseInt(e.target.value) || 0 });
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <h2 className="text-lg font-semibold text-gray-800 mb-4">Refine Your Matches</h2>

      {/* Team Category Filter */}
      <div className="mb-6">
        <h3 className="text-sm font-medium text-gray-700 mb-2">Team Category</h3>
        <div className="space-y-2">
          {categories.map((category) => (
            <div key={category} className="flex items-center">
              <input
                id={`category-${category}`}
                name="category"
                value={category}
                type="checkbox"
                checked={filters.category.includes(category)}
                onChange={(e) => handleMultipleSelect(e, 'category')}
                className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
              />
              <label htmlFor={`category-${category}`} className="ml-2 block text-sm text-gray-700">
                {category}
              </label>
            </div>
          ))}
        </div>
      </div>

      {/* Expertise Areas Filter */}
      <div className="mb-6">
        <h3 className="text-sm font-medium text-gray-700 mb-2">
          {currentTeam?.mentorshipStatus === 'offering' ? 'Areas of Expertise' : 'Areas to Improve'}
        </h3>
        <div className="space-y-2 max-h-48 overflow-y-auto">
          {expertiseAreas.map((area) => (
            <div key={area} className="flex items-center">
              <input
                id={`expertise-${area}`}
                name="expertiseAreas"
                value={area}
                type="checkbox"
                checked={filters.expertiseAreas.includes(area)}
                onChange={(e) => handleMultipleSelect(e, 'expertiseAreas')}
                className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
              />
              <label htmlFor={`expertise-${area}`} className="ml-2 block text-sm text-gray-700">
                {area}
              </label>
            </div>
          ))}
        </div>
      </div>

      {/* Mentorship Type Filter */}
      <div className="mb-6">
        <h3 className="text-sm font-medium text-gray-700 mb-2">Mentorship Type</h3>
        <select
          id="mentorshipType"
          name="mentorshipType"
          value={filters.mentorshipType}
          onChange={(e) => handleInputChange(e, 'mentorshipType')}
          className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md"
        >
          <option value="">Any Type</option>
          <option value="Virtual only">Virtual Only</option>
          <option value="In-person only">In-person Only</option>
          <option value="Virtual or In-person">Virtual or In-person</option>
        </select>
      </div>

      {/* Distance Filter */}
      <div className="mb-6">
        <h3 className="text-sm font-medium text-gray-700 mb-2">Maximum Distance (miles)</h3>
        <div className="flex items-center">
          <input
            type="range"
            min="5"
            max="500"
            step="5"
            value={filters.distance}
            onChange={(e) => handleNumericChange(e, 'distance')}
            className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
          />
          <span className="ml-2 w-12 text-center">{filters.distance}</span>
        </div>
      </div>

      {/* Experience Level Filter */}
      <div className="mb-6">
        <h3 className="text-sm font-medium text-gray-700 mb-2">
          {currentTeam?.mentorshipStatus === 'offering' ? 'Minimum Experience (years)' : 'Minimum Mentor Experience (years)'}
        </h3>
        <input
          type="number"
          min="0"
          max="20"
          value={filters.experience}
          onChange={(e) => handleNumericChange(e, 'experience')}
          className="mt-1 block w-full pl-3 pr-3 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md"
        />
      </div>

      {/* Reset Filters Button */}
      <button
        type="button"
        onClick={() => onFilterChange({
          category: [],
          expertiseAreas: [],
          mentorshipType: '',
          distance: 100,
          experience: 0
        })}
        className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
      >
        Reset Filters
      </button>
    </div>
  );
};

export default MentorshipFilters;