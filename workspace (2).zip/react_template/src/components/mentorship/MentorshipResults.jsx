import React from 'react';
import { calculateCompatibilityScore } from '../../utils/mentorshipUtils';

const MentorshipResults = ({ matches, currentTeam, loading }) => {
  // Helper function to render expertise areas or areas to improve
  const renderAreas = (team) => {
    const isOffering = team.mentorshipStatus === 'offering';
    const areas = isOffering
      ? team.mentorshipDetails.expertiseAreas
      : team.mentorshipDetails.areasToImprove;
    
    return (
      <div className="mt-2">
        <h4 className="text-sm font-medium text-gray-700">
          {isOffering ? 'Areas of Expertise:' : 'Areas to Improve:'}
        </h4>
        <div className="flex flex-wrap gap-1 mt-1">
          {areas.map((area, index) => (
            <span 
              key={index}
              className="px-2 py-1 bg-blue-100 text-blue-800 text-xs font-medium rounded"
            >
              {area}
            </span>
          ))}
        </div>
      </div>
    );
  };

  // Render loading state
  if (loading) {
    return (
      <div className="bg-white rounded-lg shadow-lg p-6">
        <div className="flex items-center justify-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-700"></div>
        </div>
        <p className="text-center text-gray-600">Finding your perfect matches...</p>
      </div>
    );
  }

  // Render empty state
  if (matches.length === 0) {
    return (
      <div className="bg-white rounded-lg shadow-lg p-6">
        <div className="text-center py-12">
          <svg className="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
          <h3 className="mt-2 text-lg font-medium text-gray-900">No matches found</h3>
          <p className="mt-1 text-sm text-gray-500">
            Try adjusting your filters to find more mentorship opportunities.
          </p>
        </div>
      </div>
    );
  }

  // Content to display if we have matches
  return (
    <div className="bg-white rounded-lg shadow-lg">
      <div className="px-6 py-4 border-b border-gray-200">
        <h2 className="text-lg font-semibold text-gray-800">
          {matches.length} {matches.length === 1 ? 'Match' : 'Matches'} Found
        </h2>
        <p className="text-sm text-gray-600">
          {currentTeam?.mentorshipStatus === 'offering' 
            ? 'Teams that could benefit from your mentoring'
            : 'Teams that could mentor you'
          }
        </p>
      </div>

      <ul className="divide-y divide-gray-200">
        {matches.map((team) => {
          const compatibilityScore = calculateCompatibilityScore(currentTeam, team);
          
          return (
            <li key={team.id} className="px-6 py-5 flex items-start">
              <div className="min-w-0 flex-1">
                <div className="flex items-center">
                  <div className="h-12 w-12 bg-gray-200 rounded-full overflow-hidden mr-4">
                    <img 
                      src={team.profileImage} 
                      alt={`${team.name} profile`}
                      className="h-full w-full object-cover" 
                    />
                  </div>
                  <div>
                    <p className="text-lg font-medium text-gray-900 flex items-center">
                      {team.name} (#{team.number})
                      <span className="ml-2 px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                        {team.category}
                      </span>
                    </p>
                    <p className="text-sm text-gray-500">{team.location}</p>
                  </div>
                  <div className="ml-auto text-right">
                    <div className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-green-100 text-green-800">
                      {compatibilityScore}% Match
                    </div>
                    <p className="text-xs text-gray-500 mt-1">
                      {team.mentorshipDetails.experience} {team.mentorshipDetails.experience === 1 ? 'year' : 'years'} experience
                    </p>
                  </div>
                </div>
                
                <div className="mt-3">
                  <p className="text-sm text-gray-600">{team.description}</p>
                  
                  {renderAreas(team)}
                  
                  <div className="mt-3 grid grid-cols-2 gap-2 text-sm">
                    <div>
                      <span className="font-medium">Availability:</span> {team.mentorshipDetails.availability}
                    </div>
                    <div>
                      <span className="font-medium">Mentorship Type:</span> {team.mentorshipDetails.mentorshipType}
                    </div>
                  </div>
                </div>
                
                <div className="mt-4">
                  <button className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                    Contact Team
                  </button>
                  <button className="ml-3 inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                    View Profile
                  </button>
                </div>
              </div>
            </li>
          );
        })}
      </ul>
    </div>
  );
};

export default MentorshipResults;