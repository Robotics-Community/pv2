// src/data/teamsData.js

export const teamsData = [
  {
    id: 1,
    name: "Robotic Eagles",
    number: 254,
    category: "FRC",
    location: "San Jose, CA",
    mentorshipStatus: "offering", // 'offering' or 'seeking'
    profileImage: "/assets/images/team_profile.jpg",
    description: "6-time world champions focused on innovation in robotics design and outreach.",
    achievements: ["World Champions 2022", "Innovation Award 2023"],
    specialties: ["Programming", "Mechanical Design", "Strategy"],
    mentorshipDetails: {
      experience: 8, // years of experience
      availability: "Weekends",
      preferredTeamTypes: ["FRC", "FTC"],
      expertiseAreas: ["Programming", "Robot Design", "Strategy"],
      mentorshipType: "Virtual and In-person",
      zipCode: "95134"
    }
  },
  {
    id: 2,
    name: "Tech Tigers",
    number: 1538,
    category: "FRC",
    location: "Detroit, MI",
    mentorshipStatus: "seeking",
    profileImage: "/assets/images/team_profile.jpg",
    description: "A team that focuses on STEM education and community outreach.",
    achievements: ["Regional Finalists 2023", "Rookie All-Star 2021"],
    specialties: ["Electronics", "Programming", "Outreach"],
    mentorshipDetails: {
      experience: 2, // years of experience
      availability: "Weekdays after 4pm",
      preferredTeamTypes: ["FRC"],
      areasToImprove: ["Programming", "Electronics", "Strategy"],
      mentorshipType: "In-person preferred",
      zipCode: "48201"
    }
  },
  {
    id: 3,
    name: "Mechanical Mayhem",
    number: 45,
    category: "FTC",
    location: "Boston, MA",
    mentorshipStatus: "offering",
    profileImage: "/assets/images/team_profile.jpg",
    description: "Specialized in innovative mechanical solutions and mentoring new teams.",
    achievements: ["State Champions 2023", "Design Award 2022"],
    specialties: ["Mechanical Design", "CAD", "Strategic Planning"],
    mentorshipDetails: {
      experience: 5,
      availability: "Weekday evenings",
      preferredTeamTypes: ["FTC", "VEX"],
      expertiseAreas: ["Mechanical Design", "CAD", "3D Printing"],
      mentorshipType: "Virtual or In-person",
      zipCode: "02108"
    }
  },
  {
    id: 4,
    name: "Coding Crusaders",
    number: 987,
    category: "FTC",
    location: "Austin, TX",
    mentorshipStatus: "seeking",
    profileImage: "/assets/images/team_profile.jpg",
    description: "A young team with a strong focus on software development and autonomous mode.",
    achievements: ["Programming Excellence Award 2023"],
    specialties: ["Programming", "Computer Vision", "Autonomous Navigation"],
    mentorshipDetails: {
      experience: 1,
      availability: "Weekends and evenings",
      preferredTeamTypes: ["FTC"],
      areasToImprove: ["Advanced Programming", "Computer Vision", "Sensor Integration"],
      mentorshipType: "Virtual preferred",
      zipCode: "78701"
    }
  },
  {
    id: 5,
    name: "Velocity Vectors",
    number: 2468,
    category: "VEX",
    location: "Chicago, IL",
    mentorshipStatus: "offering",
    profileImage: "/assets/images/team_profile.jpg",
    description: "VEX Robotics experts with multiple world championship appearances.",
    achievements: ["World Championship Division Finalists 2023", "Excellence Award 2022"],
    specialties: ["Game Strategy", "Drive Systems", "Control Systems"],
    mentorshipDetails: {
      experience: 7,
      availability: "Weekends and Thursday evenings",
      preferredTeamTypes: ["VEX", "VEX IQ"],
      expertiseAreas: ["Game Strategy", "Drive Systems", "Competition Preparation"],
      mentorshipType: "In-person only",
      zipCode: "60601"
    }
  },
  {
    id: 6,
    name: "Binary Builders",
    number: 5935,
    category: "VEX",
    location: "Seattle, WA",
    mentorshipStatus: "seeking",
    profileImage: "/assets/images/team_profile.jpg",
    description: "A team of passionate programmers focusing on efficient autonomous routines.",
    achievements: ["Think Award 2023", "Innovate Award 2022"],
    specialties: ["Programming", "Sensor Integration", "Strategy"],
    mentorshipDetails: {
      experience: 3,
      availability: "Flexible schedule",
      preferredTeamTypes: ["VEX"],
      areasToImprove: ["Advanced Programming", "Autonomous Routines", "Competition Strategy"],
      mentorshipType: "Virtual or In-person",
      zipCode: "98101"
    }
  },
  {
    id: 7,
    name: "RoboWarriors",
    number: 118,
    category: "FRC",
    location: "Houston, TX",
    mentorshipStatus: "offering",
    profileImage: "/assets/images/team_profile.jpg",
    description: "Experienced team with strong engineering principles and mentorship program.",
    achievements: ["Regional Champions 2023", "Engineering Excellence Award 2022"],
    specialties: ["Mechanical Systems", "Electronics", "Project Management"],
    mentorshipDetails: {
      experience: 10,
      availability: "Weekday evenings and weekends",
      preferredTeamTypes: ["FRC", "FTC"],
      expertiseAreas: ["Mechanical Design", "Electronics", "Project Management"],
      mentorshipType: "In-person preferred",
      zipCode: "77002"
    }
  },
  {
    id: 8,
    name: "Circuit Breakers",
    number: 842,
    category: "FTC",
    location: "Miami, FL",
    mentorshipStatus: "seeking",
    profileImage: "/assets/images/team_profile.jpg",
    description: "Focused on electrical engineering and control systems optimization.",
    achievements: ["Connect Award 2023", "Control Award 2022"],
    specialties: ["Electronics", "Wiring", "Sensors"],
    mentorshipDetails: {
      experience: 2,
      availability: "Weekends and Friday afternoons",
      preferredTeamTypes: ["FTC"],
      areasToImprove: ["Electronics", "Circuit Design", "Sensor Integration"],
      mentorshipType: "Either virtual or in-person",
      zipCode: "33101"
    }
  },
  {
    id: 9,
    name: "Precision Prototypes",
    number: 3792,
    category: "FRC",
    location: "Portland, OR",
    mentorshipStatus: "offering",
    profileImage: "/assets/images/team_profile.jpg",
    description: "Leaders in rapid prototyping and iteration methodologies.",
    achievements: ["Industrial Design Award 2023", "Quality Award 2022"],
    specialties: ["CAD", "3D Printing", "Fabrication"],
    mentorshipDetails: {
      experience: 6,
      availability: "Weekends and Wednesday evenings",
      preferredTeamTypes: ["FRC", "FTC"],
      expertiseAreas: ["CAD", "3D Printing", "Rapid Prototyping"],
      mentorshipType: "Virtual or In-person",
      zipCode: "97201"
    }
  },
  {
    id: 10,
    name: "Algorithm Aces",
    number: 6024,
    category: "VEX",
    location: "Atlanta, GA",
    mentorshipStatus: "seeking",
    profileImage: "/assets/images/team_profile.jpg",
    description: "Specialized in autonomous programming and strategic game analysis.",
    achievements: ["Autonomous Excellence Award 2023", "Strategy Award 2022"],
    specialties: ["Programming", "Autonomous Routines", "Game Analysis"],
    mentorshipDetails: {
      experience: 2,
      availability: "Monday-Thursday afternoons",
      preferredTeamTypes: ["VEX"],
      areasToImprove: ["Advanced Programming", "Autonomous Algorithms", "Strategy Optimization"],
      mentorshipType: "Virtual preferred",
      zipCode: "30303"
    }
  },
  {
    id: 11,
    name: "Quantum Mechanics",
    number: 404,
    category: "FRC",
    location: "Silicon Valley, CA",
    mentorshipStatus: "offering",
    profileImage: "/assets/images/team_profile.jpg",
    description: "Specialized in advanced programming and machine learning applications.",
    achievements: ["Innovation in Control Award 2023", "Autonomous Award 2022"],
    specialties: ["AI/ML", "Computer Vision", "Advanced Control Systems"],
    mentorshipDetails: {
      experience: 9,
      availability: "Flexible schedule",
      preferredTeamTypes: ["FRC", "FTC", "VEX"],
      expertiseAreas: ["AI/ML", "Computer Vision", "Advanced Programming"],
      mentorshipType: "Virtual only",
      zipCode: "94025"
    }
  },
  {
    id: 12,
    name: "Dynamic Drivers",
    number: 777,
    category: "FTC",
    location: "Las Vegas, NV",
    mentorshipStatus: "offering",
    profileImage: "/assets/images/team_profile.jpg",
    description: "Known for exceptional driving precision and strategic gameplay.",
    achievements: ["Tournament Champions 2023", "Driver Award 2022"],
    specialties: ["Driver Training", "Game Strategy", "Mechanical Efficiency"],
    mentorshipDetails: {
      experience: 5,
      availability: "Weekends and Tuesday/Thursday evenings",
      preferredTeamTypes: ["FTC", "FRC"],
      expertiseAreas: ["Driver Training", "Competition Strategy", "Robot Performance Optimization"],
      mentorshipType: "In-person preferred",
      zipCode: "89101"
    }
  }
];