/**
 * Utility functions for the mentorship matchmaking system
 */

// Calculate distance between two zip codes (simple placeholder algorithm)
// In a real app, this would use a zip code API or database
const calculateDistance = (zip1, zip2) => {
  // This is a placeholder implementation
  // In a real app, use a proper distance calculation with geocoding API
  if (zip1 === zip2) return 0;
  
  // Simple implementation for demo purposes - just returns a random distance
  // This should be replaced with actual zip code distance calculation
  return Math.floor(Math.random() * 100) + 5;
};

// Find matching teams based on filters and preferences
export const findMatchingTeams = (currentTeam, filters, allTeams) => {
  if (!currentTeam) return [];
  
  // Looking for teams with opposite mentorship status
  const targetStatus = currentTeam.mentorshipStatus === 'offering' ? 'seeking' : 'offering';
  
  return allTeams
    .filter(team => {
      // Exclude the current team
      if (team.id === currentTeam.id) return false;
      
      // Filter by mentorship status
      if (team.mentorshipStatus !== targetStatus) return false;
      
      // Filter by category if specified
      if (filters.category.length > 0 && !filters.category.includes(team.category)) {
        return false;
      }
      
      // Filter by mentorship type if specified
      if (filters.mentorshipType && !team.mentorshipDetails.mentorshipType.includes(filters.mentorshipType)) {
        return false;
      }
      
      // Filter by experience
      if (team.mentorshipDetails.experience < filters.experience) {
        return false;
      }
      
      // Filter by distance
      const distance = calculateDistance(currentTeam.mentorshipDetails.zipCode, team.mentorshipDetails.zipCode);
      if (distance > filters.distance) {
        return false;
      }
      
      // Filter by expertise areas/areas to improve
      if (filters.expertiseAreas.length > 0) {
        let relevantAreas;
        
        if (currentTeam.mentorshipStatus === 'offering') {
          // Current team is offering mentorship, check if their expertise matches areas the other team wants to improve
          relevantAreas = team.mentorshipDetails.areasToImprove || [];
        } else {
          // Current team is seeking mentorship, check if the other team's expertise matches their areas to improve
          relevantAreas = team.mentorshipDetails.expertiseAreas || [];
        }
        
        // Check if there's at least one matching area
        const hasMatchingArea = filters.expertiseAreas.some(area => relevantAreas.includes(area));
        if (!hasMatchingArea) return false;
      }
      
      return true;
    })
    .map(team => ({
      ...team,
      compatibilityScore: calculateCompatibilityScore(currentTeam, team)
    }))
    .sort((a, b) => b.compatibilityScore - a.compatibilityScore);
};

// Calculate compatibility score between two teams
export const calculateCompatibilityScore = (teamA, teamB) => {
  if (!teamA || !teamB) return 0;
  
  let score = 0;
  let totalPoints = 0;
  
  // Check team type preferences (25 points)
  const preferredTypes = teamA.mentorshipStatus === 'offering' 
    ? teamA.mentorshipDetails.preferredTeamTypes || []
    : teamB.mentorshipDetails.preferredTeamTypes || [];
    
  if (preferredTypes.includes(teamA.mentorshipStatus === 'offering' ? teamB.category : teamA.category)) {
    score += 25;
  }
  totalPoints += 25;
  
  // Check expertise/improvement areas match (40 points)
  const expertiseAreas = teamA.mentorshipStatus === 'offering' 
    ? teamA.mentorshipDetails.expertiseAreas || [] 
    : teamB.mentorshipDetails.expertiseAreas || [];
    
  const areasToImprove = teamA.mentorshipStatus === 'seeking' 
    ? teamA.mentorshipDetails.areasToImprove || [] 
    : teamB.mentorshipDetails.areasToImprove || [];
  
  // Count matches
  let matchingAreas = 0;
  for (const area of areasToImprove) {
    if (expertiseAreas.includes(area)) {
      matchingAreas++;
    }
  }
  
  // Calculate percentage of matching areas and award points
  const matchPercentage = areasToImprove.length > 0 
    ? Math.min(100, (matchingAreas / areasToImprove.length) * 100)
    : 0;
  
  score += (matchPercentage / 100) * 40;
  totalPoints += 40;
  
  // Check mentorship type compatibility (15 points)
  const mentorType = teamA.mentorshipStatus === 'offering' 
    ? teamA.mentorshipDetails.mentorshipType 
    : teamB.mentorshipDetails.mentorshipType;
    
  const menteeType = teamA.mentorshipStatus === 'seeking'
    ? teamA.mentorshipDetails.mentorshipType 
    : teamB.mentorshipDetails.mentorshipType;
  
  if (
    mentorType.includes('Virtual') && menteeType.includes('Virtual') ||
    mentorType.includes('In-person') && menteeType.includes('In-person')
  ) {
    score += 15;
  } else if (
    mentorType.includes('Virtual or In-person') ||
    menteeType.includes('Virtual or In-person')
  ) {
    score += 10;
  }
  totalPoints += 15;
  
  // Check location/distance (20 points)
  const distance = calculateDistance(
    teamA.mentorshipDetails.zipCode, 
    teamB.mentorshipDetails.zipCode
  );
  
  if (distance < 10) {
    score += 20; // Very close
  } else if (distance < 25) {
    score += 15; // Pretty close
  } else if (distance < 50) {
    score += 10; // Moderate distance
  } else if (distance < 100) {
    score += 5; // Significant distance
  }
  totalPoints += 20;
  
  // Calculate final percentage
  return Math.round((score / totalPoints) * 100);
};

// Get unique categories from teams data
export const getUniqueCategories = (teams) => {
  const categories = teams.map(team => team.category);
  return [...new Set(categories)];
};

// Get unique expertise areas from teams data
export const getUniqueExpertiseAreas = (teams) => {
  const areas = [];
  
  // Collect all expertise areas and areas to improve
  teams.forEach(team => {
    if (team.mentorshipDetails) {
      if (team.mentorshipDetails.expertiseAreas) {
        areas.push(...team.mentorshipDetails.expertiseAreas);
      }
      if (team.mentorshipDetails.areasToImprove) {
        areas.push(...team.mentorshipDetails.areasToImprove);
      }
    }
  });
  
  // Return unique values
  return [...new Set(areas)];
};